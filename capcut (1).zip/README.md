# CAPCUT AUTO JOIN TEAM - DAYS STORE

## 📋 DESCRIPTION
Automated script for creating CapCut accounts and joining a team. Supports 4 operation modes with timeout handling and anti-stuck features.

## 🎯 FEATURES
- **Mode 1**: Create new accounts only (generator)
- **Mode 2**: Create new accounts + auto join team
- **Mode 3**: Join team using existing accounts
- **Mode 4**: Check existing accounts validity
- Timeout handling (anti-stuck)
- Multi selector OTP
- Auto save accounts & logs

## ⚙️ INSTALLATION
1. Install **Node.js** (https://nodejs.org) - use the LTS version
2. Double click `install.bat` to install dependencies
3. Edit `config.json` to change the password (optional)

## 🚀 HOW TO USE
1. Double click `start.bat`
2. Select menu 1 to run the program
3. Follow the on-screen instructions

## 📁 FILE STRUCTURE
- `script.js` - Main script
- `config.json` - Configuration (default password)
- `accounts.txt` - List of existing accounts
- `generated_accounts.txt` - Newly generated accounts
- `join_results.txt` - Team join log
- `login_results.txt` - Account check log
- `install.bat` - Install dependencies
- `start.bat` - Main menu

## ⚙️ CONFIG.JSON
```json
{
    "password": "PasswordDefault123!"
}
```