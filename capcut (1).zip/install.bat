@echo off
title [ DAYS STORE ] - INSTALLATION
color 0A

chcp 65001 >nul

echo.
echo   ========================================
echo       [ DAYS STORE - CAPCUT AUTO JOIN ]
echo       [      INSTALLATION SCRIPT      ]
echo   ========================================
echo.

echo [INFO] Checking Node.js installation...

:: Method 1: where node
where node >nul 2>nul
if %errorlevel% equ 0 goto node_ok

:: Method 2: try node -v
node -v >nul 2>nul
if %errorlevel% equ 0 goto node_ok

:: Method 3: check common paths
if exist "C:\Program Files\nodejs\node.exe" goto node_ok
if exist "C:\Program Files (x86)\nodejs\node.exe" goto node_ok

:: If all methods fail
echo [ERROR] Node.js not found!
echo.
echo Please download and install Node.js from:
echo https://nodejs.org/ (use LTS version)
echo.
echo After installation, run this batch file again.
pause
exit /b 1

:node_ok
for /f "tokens=*" %%i in ('node -v') do set nodeversion=%%i
echo [OK] Node.js installed: %nodeversion%

echo.
echo [INFO] Checking NPM version...
for /f "tokens=*" %%i in ('npm -v') do set npmversion=%%i
echo [OK] NPM version: %npmversion%

:: Check if already installed
if exist node_modules (
    echo.
    echo [INFO] node_modules folder already exists.
    echo [INFO] Do you want to reinstall?
    set /p reinstall="[?] Reinstall? (y/n): "
)

if /i "%reinstall%"=="y" goto install
if /i "%reinstall%"=="Y" goto install
if exist node_modules (
    echo.
    echo [OK] Using existing dependencies.
    goto finish
)

:install
echo.
echo [INFO] Cleaning NPM cache...
call npm cache clean --force >nul 2>nul
echo [OK] Cache cleaned

echo.
echo [INFO] Installing dependencies (this may take a while)...
echo.

:: Only init if package.json doesn't exist
if not exist package.json (
    call npm init -y >nul 2>nul
)

echo [1/7] Installing node-fetch...
call npm install node-fetch@2 --save >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Failed to install node-fetch
    pause
    exit /b 1
) else (
    echo [OK] node-fetch installed
)

echo [2/7] Installing cheerio...
call npm install cheerio --save >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Failed to install cheerio
    pause
    exit /b 1
) else (
    echo [OK] cheerio installed
)

echo [3/7] Installing chalk...
call npm install chalk@4 --save >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Failed to install chalk
    pause
    exit /b 1
) else (
    echo [OK] chalk installed
)

echo [4/7] Installing @faker-js/faker...
call npm install @faker-js/faker --save >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Failed to install faker
    pause
    exit /b 1
) else (
    echo [OK] @faker-js/faker installed
)

echo [5/7] Installing puppeteer-extra...
call npm install puppeteer-extra --save >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Failed to install puppeteer-extra
    pause
    exit /b 1
) else (
    echo [OK] puppeteer-extra installed
)

echo [6/7] Installing puppeteer-extra-plugin-stealth...
call npm install puppeteer-extra-plugin-stealth --save >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Failed to install stealth plugin
    pause
    exit /b 1
) else (
    echo [OK] stealth plugin installed
)

echo [7/7] Installing puppeteer (browser)...
call npm install puppeteer --save >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Failed to install puppeteer
    pause
    exit /b 1
) else (
    echo [OK] puppeteer installed
)

echo.
echo [OK] All dependencies installed successfully!

:finish
echo.
echo [INFO] Creating config.json if not exists...
if not exist config.json (
    echo { > config.json
    echo     "password": "qweqweqwe" >> config.json
    echo } >> config.json
    echo [OK] config.json created with default password
) else (
    echo [OK] config.json already exists
)

echo.
echo [INFO] Creating placeholder files...
if not exist accounts.txt (
    echo # List of existing accounts (format: email^^^|password) > accounts.txt
    echo # Example: user@gmail.com^^^|password123 >> accounts.txt
    echo. >> accounts.txt
    echo [OK] accounts.txt created
)

if not exist generated_accounts.txt (
    echo # Newly generated accounts will be saved here > generated_accounts.txt
    echo. >> generated_accounts.txt
    echo [OK] generated_accounts.txt created
)

echo.
echo ========================================
echo        INSTALLATION COMPLETE!
echo ========================================
echo.
echo How to run the program:
echo 1. Double click start.bat
echo 2. Or type: node script.js
echo.
echo Do not forget to edit the password in config.json
echo to your preference.
echo.
echo Thank you for using
echo DAYS STORE - CAPCUT AUTO JOIN
echo ========================================
echo.

pause