/*
 * CAPCUT AUTO JOIN TEAM - ULTIMATE EDITION
 * CODED BY DAYS STORE
 * Mode: Hybrid + Multi-Mode dengan Timeout Handling & Anti-Stuck
 * FIXED: Login dengan Playwright untuk account existing
 * * 5 OPERATION MODES:
 * 1. Mode 1: Create New Accounts ONLY (Generator Only)
 * 2. Mode 2: Create New Accounts + JOIN TEAM (Head Generator Maks 29 Account + Auto Retry 3x + 2 WORKER)
 * 3. Mode 3: JOIN TEAM with Existing Accounts
 * 4. Mode 4: CHECK/LOGIN Existing Accounts (Validation)
 * 5. Mode 5: KICK MEMBER from Team (Use head.txt)
 */

import fetch from "node-fetch";
import * as cheerio from 'cheerio';
import chalk from 'chalk';
import { faker } from '@faker-js/faker';
import { promises as fs, readFileSync } from 'fs';
import { createInterface } from 'readline';
import { chromium } from 'playwright';

// --- HYBRID ENGINE: PUPPETEER ---
import puppeteer from 'puppeteer-extra';
import StealthPlugin from 'puppeteer-extra-plugin-stealth';
puppeteer.use(StealthPlugin());

// --- CONFIGURATION LOADER ---
const loadConfig = () => {
    try {
        return JSON.parse(readFileSync('./config.json', 'utf-8'));
    } catch (e) {
        console.log(chalk.red("[!] CRITICAL: config.json not found or invalid!"));
        console.log(chalk.yellow("[*] Creating config.json with default values..."));
        const defaultConfig = {
            password: "DaysStore123!",
            custom_domains: ["narcoboy.sbs", "ohgitu.me", "lapakqu.com"]
        };
        fs.writeFileSync('./config.json', JSON.stringify(defaultConfig, null, 2));
        return defaultConfig;
    }
};

const config = loadConfig();

// --- UTILITIES & CRYPTO ---
class Utils {
    static sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    static encryptToTargetHex(input) {
        let hexResult = "";
        for (const char of input) {
            const encryptedCharCode = char.charCodeAt(0) ^ 0x05;
            hexResult += encryptedCharCode.toString(16).padStart(2, "0");
        }
        return hexResult;
    }

    static getCurrentTime() {
        const now = new Date();
        return `[${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}]`;
    }

    static parseCookies(response) {
        const raw = response.headers.raw()['set-cookie'];
        return raw ? raw.map((entry) => entry.split(';')[0]).join('; ') : "";
    }

    static getBanner() {
        console.clear();
        console.log(chalk.greenBright(`
  ██████╗  █████╗ ██╗   ██╗███████╗
 ██╔══██╗██╔══██╗╚██╗ ██╔╝██╔════╝
 ██║  ██║███████║ ╚████╔╝ ███████╗
 ██║  ██║██╔══██║  ╚██╔╝  ╚════██║
 ██████╔╝██║  ██║   ██║   ███████║
 ╚═════╝ ╚═╝  ╚═╝   ╚═╝   ╚══════╝
       [ DAYS STORE : ULTIMATE ]
       [   5 OPERATION MODES   ]
`));
        console.log(chalk.gray("--------------------------------------------------"));
    }

    // Fungsi untuk login dengan account existing
    static async loginWithExisting(email, password) {
        let browser = null;
        let context = null;
        let page = null;
        
        try {
            console.log(chalk.cyan(`${Utils.getCurrentTime()} [>] Opening browser for login: ${email}`));
            
            browser = await chromium.launch({ 
                headless: true,
                args: ['--no-sandbox']
            });
            
            context = await browser.newContext({
                userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            });
            
            page = await context.newPage();
            page.setDefaultTimeout(30000);
            
            // Buka halaman signup
            await page.goto('https://www.capcut.com/id-id/signup', { 
                waitUntil: 'domcontentloaded' 
            }).catch(() => {});
            
            await page.waitForTimeout(2000);
            
            // ISI EMAIL
            let emailBox = null;
            if (page.getByRole) {
                emailBox = page.getByRole('textbox', { name: /masukkan alamat email|enter your email/i });
            }
            if (!emailBox || (emailBox.count && await emailBox.count() === 0)) {
                emailBox = page.locator('input[type="email"], input[name="email"], input[placeholder*="email"]');
            }
            if (!emailBox || (emailBox.count && await emailBox.count() === 0)) {
                emailBox = page.locator('input').first();
            }
            
            await emailBox.waitFor({ state: 'visible', timeout: 10000 }).catch(() => {});
            await emailBox.click().catch(() => {});
            await emailBox.fill(email);
            console.log(chalk.gray(`[DEBUG] Email filled: ${email}`));
            
            await page.waitForTimeout(1000);
            
            // KLIK LANJUTKAN
            let continueClicked = false;
            const continueTexts = ['Lanjutkan', 'Continue', 'Next', 'Berikutnya', 'Selanjutnya'];
            for (const text of continueTexts) {
                if (continueClicked) break;
                try {
                    if (page.getByRole) {
                        const btn = page.getByRole('button', { name: new RegExp(text, 'i') });
                        if (await btn.count() > 0) {
                            await btn.first().click();
                            continueClicked = true;
                            break;
                        }
                    }
                    const btnByText = await page.$(`button:has-text("${text}")`);
                    if (btnByText) {
                        await btnByText.click();
                        continueClicked = true;
                        break;
                    }
                } catch (e) {}
            }
            if (!continueClicked) {
                const submitBtn = await page.$('button[type="submit"]');
                if (submitBtn) {
                    await submitBtn.click();
                    continueClicked = true;
                }
            }
            if (!continueClicked) throw new Error('Continue button not found');
            console.log(chalk.gray(`[DEBUG] Continue button clicked`));
            
            await page.waitForLoadState('domcontentloaded').catch(() => {});
            await page.waitForTimeout(3000);
            
            // CARI INPUT PASSWORD
            let passBox = null;
            if (page.getByRole) {
                passBox = page.getByRole('textbox', { name: /masuk(?:kan|an)?\s*kata\s*sandi|enter password|password/i });
            }
            if (!passBox || (passBox.count && await passBox.count() === 0)) {
                if (page.getByLabel) {
                    passBox = page.getByLabel(/masuk(?:kan|an)?\s*kata\s*sandi|password|sandi/i);
                }
            }
            if (!passBox || (passBox.count && await passBox.count() === 0)) {
                passBox = page.locator('input[type="password"]');
            }
            if (!passBox || (passBox.count && await passBox.count() === 0)) {
                passBox = page.locator('input[placeholder*="sandi"], input[placeholder*="password"]');
            }
            
            if (!passBox || (passBox.count && await passBox.count() === 0)) {
                console.log(chalk.yellow(`[DEBUG] Password input not found, coba buka /login`));
                await page.goto('https://www.capcut.com/id-id/login', { waitUntil: 'domcontentloaded' }).catch(() => {});
                await page.waitForTimeout(2000);
                passBox = page.locator('input[type="password"]');
            }
            
            if (!passBox || (passBox.count && await passBox.count() === 0)) {
                await page.screenshot({ path: 'debug-password-not-found.png' });
                throw new Error('Password input not found');
            }
            
            await passBox.waitFor({ state: 'visible', timeout: 5000 }).catch(() => {});
            await passBox.click().catch(() => {});
            await passBox.fill(password);
            console.log(chalk.gray(`[DEBUG] Password filled`));
            
            await page.waitForTimeout(1000);
            
            // KLIK TOMBOL MASUK
            let loginClicked = false;
            const loginTexts = ['Masuk', 'Log in', 'Sign in', 'Login'];
            for (const text of loginTexts) {
                if (loginClicked) break;
                try {
                    if (page.getByRole) {
                        const btn = page.getByRole('button', { name: new RegExp(text, 'i') });
                        if (await btn.count() > 0) {
                            await btn.first().click();
                            loginClicked = true;
                            break;
                        }
                    }
                    const btnByText = await page.$(`button:has-text("${text}")`);
                    if (btnByText) {
                        await btnByText.click();
                        loginClicked = true;
                        break;
                    }
                } catch (e) {}
            }
            if (!loginClicked) {
                const submitBtn = await page.$('button[type="submit"]');
                if (submitBtn) {
                    await submitBtn.click();
                    loginClicked = true;
                }
            }
            if (!loginClicked) throw new Error('Login button not found');
            console.log(chalk.gray(`[DEBUG] Login button clicked`));
            
            await page.waitForLoadState('networkidle', { timeout: 20000 }).catch(() => {});
            await page.waitForTimeout(6000);
            
            const cookies = await context.cookies();
            const cookieString = cookies.map(c => `${c.name}=${c.value}`).join('; ');
            
            const currentUrl = page.url();
            const pageContent = await page.content();
            const pageText = pageContent.toLowerCase();
            
            const isLoggedIn = (
                pageText.includes('perpanjang pro') || 
                pageText.includes('extend pro') ||
                pageText.includes('dashboard') ||
                pageText.includes('my-edit') ||
                pageText.includes('kelola account') ||
                pageText.includes('pro') ||
                currentUrl.includes('my-edit') ||
                currentUrl.includes('dashboard') ||
                currentUrl.includes('workspace')
            );
            
            if (isLoggedIn) {
                console.log(chalk.green(`${Utils.getCurrentTime()} [+] ✅ Login successful for ${email}`));
                if (typeof AccountHandler.saveValidAccount === 'function') {
                    await AccountHandler.saveValidAccount(email, password);
                }
                return { success: true, cookies: cookieString, data: { message: "success" }, email: email };
            } else {
                if (pageText.includes('invalid email or password') || pageText.includes('invalid email or password')) {
                    throw new Error('Invalid email or password');
                } else if (pageText.includes('captcha') || pageText.includes('verifikasi')) {
                    throw new Error('Captcha detected');
                } else {
                    await page.screenshot({ path: 'debug-login-failed.png' });
                    throw new Error('Login failed - No success indicator');
                }
            }
            
        } catch (error) {
            console.log(chalk.red(`${Utils.getCurrentTime()} [!] ❌ Login failed for ${email}: ${error.message}`));
            return { success: false, error: error.message, data: { message: "failed" }, email: email };
        } finally {
            if (page) await page.close().catch(() => {});
            if (context) await context.close().catch(() => {});
            if (browser) await browser.close().catch(() => {});
        }
    }
}

// --- LOGGER SYSTEM ---
class Logger {
    static info(msg) { console.log(chalk.cyan(`${Utils.getCurrentTime()} [*] ${msg}`)); }
    static success(msg) { console.log(chalk.greenBright(`${Utils.getCurrentTime()} [+] ${msg}`)); }
    static error(msg) { console.log(chalk.red(`${Utils.getCurrentTime()} [!] ${msg}`)); }
    static warn(msg) { console.log(chalk.yellow(`${Utils.getCurrentTime()} [?] ${msg}`)); }
    static process(msg) { console.log(chalk.magenta(`${Utils.getCurrentTime()} [>] ${msg}`)); }
}

// --- EMAIL HANDLER ---
class EmailService {
    static async fetchWithTimeout(url, options = {}, timeout = 10000) {
        const controller = new AbortController();
        const id = setTimeout(() => controller.abort(), timeout);
        try {
            const response = await fetch(url, { ...options, signal: controller.signal });
            clearTimeout(id);
            return response;
        } catch (error) {
            clearTimeout(id);
            throw error;
        }
    }

    static async getDomains() {
        try {
            if (config.custom_domains && config.custom_domains.length > 0) {
                return config.custom_domains;
            }
            const res = await EmailService.fetchWithTimeout('https://generator.email/');
            const text = await res.text();
            const $ = cheerio.load(text);
            const result = [];
            $('.e7m.tt-suggestions').find('div > p').each((_, element) => {
                result.push($(element).text());
            });
            return result.length > 0 ? result : ["narcoboy.sbs", "ohgitu.me", "lapakqu.com"];
        } catch (err) {
            Logger.error(`Domain fetch failed: ${err.message}`);
            return ["narcoboy.sbs", "ohgitu.me", "lapakqu.com"];
        }
    }
    
    static async checkInbox(email, domain) {
        try {
            const [username] = email.split('@');
            const headers = {
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
                'accept-language': 'en-US,en;q=0.9',
                'cookie': `surl=${domain}/${username}`,
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            };
            const res = await EmailService.fetchWithTimeout('https://generator.email/', { headers }, 10000);
            if (!res.ok) return null;
            const text = await res.text();
            const $ = cheerio.load(text);
            const selectors = [
                "#email-table > div.e7m.row.list-group-item > div.e7m.col-md-12.ma1 > div.e7m.mess_bodiyy > div > div > div:nth-child(2) > p:nth-child(2) > span",
                "#email-table > div.e7m.list-group-item.list-group-item-info > div.e7m.subj_div_45g45gg",
                ".e7m.mess_bodiyy span"
            ];
            for (const selector of selectors) {
                const text = $(selector).text().trim();
                const codeMatch = text.match(/\d{6}/);
                if (codeMatch) return codeMatch[0];
            }
            return null;
        } catch (err) {
            return null;
        }
    }
}

// --- BROWSER AUTOMATION (JOIN TEAM) ---
class BrowserHandler {
    static async forceJoin(targetLink, cookiesString) {
        let browser = null;
        try {
            // Hilangkan log besar agar 2 worker tidak spam terminal
            browser = await puppeteer.launch({
                headless: true,
                defaultViewport: { width: 1280, height: 720 },
                args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-web-security', '--start-maximized']
            });
            const pages = await browser.pages();
            const page = pages[0];
            await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36');
            if (cookiesString) {
                const cookieArray = cookiesString.split('; ').map(c => {
                    const parts = c.split('=');
                    return { name: parts[0], value: parts.slice(1).join('='), domain: '.capcut.com', path: '/' };
                });
                await page.setCookie(...cookieArray);
            }
            await page.goto(targetLink, { waitUntil: 'networkidle2', timeout: 60000 });
            await Utils.sleep(3000);
            const onboardingBtn = await page.$('button.lv-btn-primary');
            if (onboardingBtn) {
                const btnText = await page.evaluate(el => el.innerText, onboardingBtn);
                if (btnText.includes('Buka CapCut') || btnText.includes('Open CapCut')) {
                    await onboardingBtn.click();
                    await Utils.sleep(5000);
                    await page.goto(targetLink, { waitUntil: 'networkidle2', timeout: 60000 });
                    await Utils.sleep(3000);
                }
            }
            try {
                await page.waitForSelector('button.lv-btn-primary', { timeout: 15000 });
                const clickResult = await page.evaluate(() => {
                    const buttons = Array.from(document.querySelectorAll('button'));
                    const target = buttons.find(b => {
                        const t = b.innerText.toLowerCase();
                        return t.includes('kirim') || t.includes('join') || t.includes('gabung');
                    });
                    if (target) {
                        target.click();
                        return { found: true, text: target.innerText };
                    }
                    return { found: false, text: "N/A" };
                });
                if (clickResult.found) {
                    await Utils.sleep(5000);
                    return { success: true, msg: "JOIN SUCCESS" };
                } else {
                    await page.click('button.lv-btn-primary');
                    await Utils.sleep(5000);
                    return { success: true, msg: "FORCE JOIN ATTEMPTED" };
                }
            } catch (e) {
                const currentUrl = page.url();
                if (currentUrl.includes('/space') || currentUrl.includes('/my-cloud')) {
                    return { success: true, msg: "ALREADY JOINED" };
                }
                return { success: false, msg: "BUTTON NOT FOUND" };
            }
        } catch (e) {
            return { success: false, msg: `Browser Error: ${e.message}` };
        } finally {
            if (browser) await browser.close();
        }
    }
}

// ============================================
// ACCOUNT HANDLER
// ============================================
class AccountHandler {
    static async loadAccountsFromFile(filename) {
        try {
            const fileContent = await fs.readFile(filename, 'utf-8');
            const lines = fileContent.split('\n').filter(line => line.trim() !== '');
            const accounts = [];
            for (const line of lines) {
                let parts = [];
                if (line.includes('|')) parts = line.split('|');
                else if (line.includes(':')) parts = line.split(':');
                else if (line.includes(',')) parts = line.split(',');
                if (parts.length >= 2) {
                    accounts.push({ email: parts[0].trim(), password: parts[1].trim() });
                }
            }
            return accounts;
        } catch (err) {
            return [];
        }
    }
    
    static async saveAccount(email, password, filename = 'generated_accounts.txt') {
        try {
            const credential = `${email}|${password}\n`;
            await fs.writeFile(filename, credential, { flag: 'a' });
            return true;
        } catch (e) {
            return false;
        }
    }
    
    static async saveResult(email, status, message, mode) {
        const result = `${Utils.getCurrentTime()} | [${mode}] | ${email} | ${status} | ${message}\n`;
        await fs.writeFile('join_results.txt', result, { flag: 'a' });
    }
    
    static async saveLoginResult(email, status, message) {
        const result = `${Utils.getCurrentTime()} | ${email} | ${status} | ${message}\n`;
        await fs.writeFile('login_results.txt', result, { flag: 'a' });
    }
    
    static async saveValidAccount(email, password) {
        try {
            const credential = `${email}|${password}\n`;
            await fs.writeFile('valid_accounts.txt', credential, { flag: 'a' });
            return true;
        } catch (e) {
            return false;
        }
    }
    
    static async saveKickResult(userId, status, message) {
        try {
            const result = `${Utils.getCurrentTime()} | ${userId} | ${status} | ${message}\n`;
            await fs.writeFile('kick_results.txt', result, { flag: 'a' });
        } catch (e) {}
    }
}

// ============================================
// CORE EXPLOIT CLASS
// ============================================
class CapCutExploit {
    constructor() {
        this.baseUrl = 'https://www.capcut.com/passport/web/email';
        this.commonHeaders = {
            'Content-Type': 'application/x-www-form-urlencoded',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        };
    }

    async register(encryptedEmail, encryptedPassword) {
        try {
            const url = new URL(`${this.baseUrl}/send_code/`);
            const params = { aid: '348188', account_sdk_source: 'web', language: 'en', verifyFp: 'verify_m7euzwhw_PNtb4tlY_I0az_4me0_9Hrt_sEBZgW5GGPdn', check_region: '1' };
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
            const formData = new URLSearchParams();
            formData.append('mix_mode', '1');
            formData.append('email', encryptedEmail);
            formData.append('password', encryptedPassword);
            formData.append('type', '34');
            formData.append('fixed_mix_mode', '1');
            const response = await EmailService.fetchWithTimeout(url.toString(), {
                method: 'POST',
                headers: this.commonHeaders,
                body: formData
            }, 15000);
            return await response.json();
        } catch (e) {
            return { message: "Network Error/Timeout" };
        }
    }

    async verify(encryptedEmail, encryptedPassword, encryptedCode) {
        try {
            const originalDate = faker.date.birthdate();
            const formattedDate = originalDate.toISOString().split('T')[0];
            const url = new URL(`${this.baseUrl}/register_verify_login/`);
            const params = { aid: '348188', account_sdk_source: 'web', language: 'en', verifyFp: 'verify_m7euzwhw_PNtb4tlY_I0az_4me0_9Hrt_sEBZgW5GGPdn', check_region: '1' };
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
            const formData = new URLSearchParams();
            formData.append('mix_mode', '1');
            formData.append('email', encryptedEmail);
            formData.append('code', encryptedCode);
            formData.append('password', encryptedPassword);
            formData.append('type', '34');
            formData.append('birthday', formattedDate);
            formData.append('force_user_region', 'ID');
            formData.append('biz_param', '{}');
            formData.append('check_region', '1');
            formData.append('fixed_mix_mode', '1');
            const response = await EmailService.fetchWithTimeout(url.toString(), {
                method: 'POST',
                headers: this.commonHeaders,
                body: formData
            }, 15000);
            const data = await response.json();
            const cookies = Utils.parseCookies(response);
            return { data, cookies };
        } catch (e) {
            return { data: { message: "Network Error/Timeout" }, cookies: null };
        }
    }
}

// ============================================
// FUNGSI-FUNGSI KICK MEMBER
// ============================================

// --- Fungsi auto scroll ---
async function autoScroll(page) {
    await page.evaluate(async () => {
        await new Promise((resolve) => {
            let totalHeight = 0;
            const distance = 100;
            const timer = setInterval(() => {
                const scrollHeight = document.body.scrollHeight;
                window.scrollBy(0, distance);
                totalHeight += distance;
                if (totalHeight >= scrollHeight) {
                    clearInterval(timer);
                    resolve();
                }
            }, 100);
        });
    });
}

// --- Fungsi untuk menutup popup (dengan delay lebih panjang) ---
async function dismissAllPopups(page) {
    try {
        Logger.process("Finding and closing popup/overlay...");
        
        // TUNGGU LEBIH LAMA UNTUK POPUP MUNCUL
        Logger.process("Waiting for popup to appear...");
        await Utils.sleep(5000); // Delay 5 seconds pertama
        
        // Strategi 1: Tombol teks
        const closeTexts = [
            'Maybe later', 'Later', 'Skip', 'Tutup', 'Close', 
            'Nanti', 'Lewati', 'OK', 'Got it', 'Mengerti',
            'No thanks', 'Not now', 'Batal', 'Cancel',
            'Generate'
        ];
        
        for (const text of closeTexts) {
            try {
                const button = await page.$(`button:has-text("${text}")`);
                if (button && await button.isVisible()) {
                    await button.click();
                    Logger.info(`✅ Closing popup with button: ${text}`);
                    await Utils.sleep(1500);
                }
            } catch (e) {}
        }
        
        // Strategi 2: Icon close
        const closeIcons = await page.$$('svg, i, span, button');
        for (const icon of closeIcons) {
            try {
                const html = await page.evaluate(el => el.outerHTML, icon);
                if (html.includes('close') || html.includes('Close') || html.includes('x') || html.includes('X')) {
                    if (await icon.isVisible()) {
                        await icon.click();
                        Logger.info(`✅ Closing popup with close icon`);
                        await Utils.sleep(1000);
                        break;
                    }
                }
            } catch (e) {}
        }
        
        // Strategi 3: Tekan Escape
        for (let i = 0; i < 3; i++) {
            await page.keyboard.press('Escape');
            await Utils.sleep(500);
        }
        
        // Strategi 4: Klik pojok
        try {
            await page.mouse.click(10, 10);
            await Utils.sleep(500);
            const dimensions = await page.evaluate(() => ({ width: window.innerWidth, height: window.innerHeight }));
            await page.mouse.click(dimensions.width - 10, 10);
            await Utils.sleep(500);
        } catch (e) {}
        
        // Strategi 5: Sembunyikan modal via JavaScript
        await page.evaluate(() => {
            const modalSelectors = ['[class*="modal"]', '[class*="overlay"]', '[class*="popup"]', '[class*="dialog"]'];
            modalSelectors.forEach(selector => {
                document.querySelectorAll(selector).forEach(el => {
                    if (el.style) {
                        el.style.display = 'none';
                        el.style.visibility = 'hidden';
                        el.style.opacity = '0';
                        el.style.pointerEvents = 'none';
                    }
                });
            });
        });
        
        Logger.success("✅ Popup/overlay handling completed");
        
        // Cek masih ada popup
        const stillHasPopup = await page.evaluate(() => {
            const text = document.body.innerText.toLowerCase();
            return text.includes('maybe later') || text.includes('switch to') || text.includes('terms of service');
        });
        
        if (stillHasPopup) {
            Logger.warn("⚠️ Popup still exists, trying again...");
            await Utils.sleep(2000);
            return dismissAllPopups(page);
        }
        return true;
        
    // TUNGGU EKSTRA SETELAH MENUTUP POPUP
        await Utils.sleep(2000);
        
    } catch (error) {
        Logger.error(`Error saat menutup popup: ${error.message}`);
        return false;
    }
}

// --- Fungsi untuk klik avatar/profile ---
async function clickAvatar(page) {
    try {
        Logger.process("Finding avatar/profile...");
        
        const avatarSelectors = [
            'div.work-space-header img',
            'xpath///*[@id="platform-content-container"]/div[1]/div[3]/div/span/img',
            'aria/avatar',
            '.user-avatar',
            '.lv-avatar',
            '[class*="avatar"]'
        ];
        
        for (const selector of avatarSelectors) {
            if (selector.startsWith('xpath')) {
                const element = await page.$x(selector.replace('xpath', ''));
                if (element.length > 0 && await element[0].isVisible()) {
                    await element[0].click();
                    Logger.info(`✅ Click avatar with xpath`);
                    await Utils.sleep(2000);
                    return true;
                }
            } else {
                const element = await page.$(selector);
                if (element && await element.isVisible()) {
                    await element.click();
                    Logger.info(`✅ Click avatar with selector: ${selector}`);
                    await Utils.sleep(2000);
                    return true;
                }
            }
        }
        
        const dimensions = await page.evaluate(() => ({
            width: window.innerWidth,
            height: window.innerHeight
        }));
        await page.mouse.click(dimensions.width - 50, 50);
        Logger.info(`✅ Click top right corner (fallback)`);
        await Utils.sleep(2000);
        return true;
        
    } catch (e) {
        Logger.error(`Error click avatar: ${e.message}`);
        return false;
    }
}

// --- Fungsi untuk klik menu Settings dari dropdown (dengan delay) ---
async function clickSettingsFromDropdown(page) {
    try {
        Logger.process("Finding Settings menu in dropdown...");
        
        const settingsSelectors = [
            'div:nth-of-type(7) div:nth-of-type(6) > div',
            'xpath//html/body/div[7]/span/div[2]/div/div/div[2]/div[6]/div',
            'div:nth-of-type(6) div:nth-of-type(6) > div',
            'xpath//html/body/div[6]/span/div[2]/div/div/div[2]/div[6]/div',
            'text="Settings"',
            'aria/Settings',
            'button:has-text("Settings")',
            'a:has-text("Settings")'
        ];
        
        for (const selector of settingsSelectors) {
            try {
                if (selector.startsWith('xpath')) {
                    const element = await page.$x(selector.replace('xpath', ''));
                    if (element.length > 0 && await element[0].isVisible()) {
                        await element[0].click();
                        Logger.info(`✅ Click Settings from dropdown (xpath)`);
                        
                        // Tunggu navigasi ke halaman settings
                        await page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 15000 }).catch(() => {});
                        await Utils.sleep(5000); // Delay 5 seconds setelah masuk halaman Settings
                        return true;
                    }
                } else if (selector.startsWith('text=')) {
                    const text = selector.replace('text=', '');
                    const element = await page.$(`text="${text}"`);
                    if (element && await element.isVisible()) {
                        await element.click();
                        Logger.info(`✅ Click Settings from dropdown (text)`);
                        await page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 15000 }).catch(() => {});
                        await Utils.sleep(5000);
                        return true;
                    }
                } else {
                    const element = await page.$(selector);
                    if (element && await element.isVisible()) {
                        await element.click();
                        Logger.info(`✅ Click Settings from dropdown: ${selector}`);
                        await page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 15000 }).catch(() => {});
                        await Utils.sleep(5000);
                        return true;
                    }
                }
            } catch (e) {}
        }
        
        return false;
    } catch (e) {
        Logger.error(`Error click settings dropdown: ${e.message}`);
        return false;
    }
}

// --- Fungsi untuk klik menu Members di sidebar (TANPA DISMISS POPUP) ---
async function clickMembersSidebar(page) {
    try {
        Logger.process("Finding Members menu in sidebar...");
        
        // TUNGGU HALAMAN SETTINGS LOAD
        Logger.process("Waiting for Settings page to load...");
        await Utils.sleep(5000);
        
        // CEK URL UNTUK MENENTUKAN SELECTOR YANG TEPAT
        const currentUrl = page.url();
        Logger.info(`Current URL: ${currentUrl}`);
        
        // STEP 1: Cari dan klik menu "Spaces" terlebih dahulu
        Logger.process("Finding Spaces menu...");
        
        const spacesSelectors = [
            'div.lv-menu div:nth-of-type(2)',
            'xpath///*[@id="root"]/div/div[2]/div/div/div[1]/div[2]/div/div[2]',
            'aria/Spaces',
            'text="Spaces"',
            'text="Ruang"'
        ];
        
        let spacesClicked = false;
        
        for (const selector of spacesSelectors) {
            try {
                if (selector.startsWith('xpath')) {
                    const element = await page.$x(selector.replace('xpath', ''));
                    if (element.length > 0 && await element[0].isVisible()) {
                        await element[0].click();
                        Logger.info(`✅ Klik menu Spaces (xpath)`);
                        spacesClicked = true;
                        await Utils.sleep(3000);
                        break;
                    }
                } else {
                    const element = await page.$(selector);
                    if (element && await element.isVisible()) {
                        await element.click();
                        Logger.info(`✅ Klik menu Spaces: ${selector}`);
                        spacesClicked = true;
                        await Utils.sleep(3000);
                        break;
                    }
                }
            } catch (e) {}
        }
        
        if (!spacesClicked) {
            Logger.warn("⚠️ Menu Spaces not found, mungkin sudah di halaman Spaces");
        }
        
        // TUNGGU HALAMAN SPACES LOAD
        await Utils.sleep(4000);
        
        // STEP 2: Cari icon titik tiga (menu) untuk space pertama
        Logger.process("Mencari menu space...");
        
        const spaceMenuSelectors = [
            'div.lv-table svg',
            'xpath///*[@id="root"]/div/div[2]/div/div/div[2]/div/div[2]/div/div/div/div/div/table/tbody/tr/td[4]/div/span/div/svg',
            'button[class*="more"] svg'
        ];
        
        for (const selector of spaceMenuSelectors) {
            try {
                if (selector.startsWith('xpath')) {
                    const element = await page.$x(selector.replace('xpath', ''));
                    if (element.length > 0 && await element[0].isVisible()) {
                        await element[0].click();
                        Logger.info(`✅ Klik menu space (xpath)`);
                        await Utils.sleep(2000);
                        break;
                    }
                } else {
                    const element = await page.$(selector);
                    if (element && await element.isVisible()) {
                        await element.click();
                        Logger.info(`✅ Klik menu space: ${selector}`);
                        await Utils.sleep(2000);
                        break;
                    }
                }
            } catch (e) {}
        }
        
        await Utils.sleep(2000);
        
        // STEP 3: Klik "Settings" dari dropdown menu space
        Logger.process("Mencari Settings di dropdown space...");
        
        const spaceSettingsSelectors = [
            'div:nth-of-type(2) > div.spacePageDropdownText-wHaVjj',
            'xpath//html/body/div[4]/span/div/div/div[2]/div[2]',
            'text="Settings"',
            'aria/Settings'
        ];
        
        for (const selector of spaceSettingsSelectors) {
            try {
                if (selector.startsWith('xpath')) {
                    const element = await page.$x(selector.replace('xpath', ''));
                    if (element.length > 0 && await element[0].isVisible()) {
                        await element[0].click();
                        Logger.info(`✅ Click Settings from dropdown space (xpath)`);
                        await page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 15000 }).catch(() => {});
                        await Utils.sleep(5000);
                        break;
                    }
                } else {
                    const element = await page.$(selector);
                    if (element && await element.isVisible()) {
                        await element.click();
                        Logger.info(`✅ Click Settings from dropdown space: ${selector}`);
                        await page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 15000 }).catch(() => {});
                        await Utils.sleep(5000);
                        break;
                    }
                }
            } catch (e) {}
        }
        
        // TUNGGU HALAMAN SPACE SETTINGS LOAD
        Logger.process("Waiting halaman Space Settings load...");
        await Utils.sleep(5000);
        
        // STEP 4: CARI MENU MEMBERS
        Logger.process("Mencari menu Members di space settings...");
        
        const membersSelectors = [
            'div:nth-of-type(3) div.lv-menu div:nth-of-type(2)',
            'xpath//html/body/div[3]/div[2]/div/div[2]/div/section/aside/div/div[2]/div/div[2]',
            'aria/Members',
            'text="Members"',
            'text="Anggota"',
            'button:has-text("Members")',
            'div.lv-menu div:nth-of-type(2)'
        ];
        
        for (const selector of membersSelectors) {
            try {
                Logger.process(`Mencoba selector: ${selector}`);
                
                if (selector.startsWith('xpath')) {
                    const element = await page.$x(selector.replace('xpath', ''));
                    if (element.length > 0 && await element[0].isVisible()) {
                        await element[0].click();
                        Logger.info(`✅ Klik Members sidebar (xpath)`);
                        await Utils.sleep(3000);
                        return true;
                    }
                } else {
                    const element = await page.$(selector);
                    if (element && await element.isVisible()) {
                        await element.click();
                        Logger.info(`✅ Klik Members sidebar: ${selector}`);
                        await Utils.sleep(3000);
                        return true;
                    }
                }
            } catch (e) {
                Logger.warn(`Selector ${selector} failed: ${e.message}`);
            }
        }
        
        return false;
    } catch (e) {
        Logger.error(`Error click members sidebar: ${e.message}`);
        return false;
    }
}

// --- Fungsi untuk klik menu member (titik tiga) ---
async function clickMemberMenu(page, memberIndex) {
    try {
        Logger.process(`Mencari menu untuk member ${memberIndex}...`);
        
        // Tunggu daftar member load
        await Utils.sleep(2000);
        
        // Selector dari recording
        const menuSelectors = [
            'div.members-panel-content > div:nth-of-type(2) svg',
            'xpath//html/body/div[3]/div[2]/div/div[2]/div/section/main/div/div[2]/div[1]/div[2]/div/svg',
            'div.members-panel-content > div:nth-of-type(2) div.member-item-role',
            'xpath//html/body/div[3]/div[2]/div/div[2]/div/section/main/div/div[2]/div[1]/div[2]/div/div[2]',
            'div.lv-table svg'
        ];
        
        for (const selector of menuSelectors) {
            try {
                if (selector.startsWith('xpath')) {
                    const elements = await page.$x(selector.replace('xpath', ''));
                    // Ambil elemen sesuai index (memberIndex)
                    if (elements.length >= memberIndex && await elements[memberIndex - 1].isVisible()) {
                        await elements[memberIndex - 1].click();
                        Logger.info(`✅ Klik menu member ${memberIndex} (xpath)`);
                        await Utils.sleep(1000);
                        return true;
                    }
                } else {
                    const elements = await page.$$(selector);
                    if (elements.length >= memberIndex && await elements[memberIndex - 1].isVisible()) {
                        await elements[memberIndex - 1].click();
                        Logger.info(`✅ Klik menu member ${memberIndex}: ${selector}`);
                        await Utils.sleep(1000);
                        return true;
                    }
                }
            } catch (e) {}
        }
        
        return false;
    } catch (e) {
        Logger.error(`Error click member menu: ${e.message}`);
        return false;
    }
}

// --- Fungsi untuk mengecek apakah masih di halaman Settings (untuk navigasi kembali jika perlu) ---
async function navigateBackToMembers(page) {
    try {
        // Cek apakah masih di halaman Settings
        const currentUrl = page.url();
        if (currentUrl.includes('/settings')) {
            Logger.process("Masih di halaman Settings, mencoba navigasi kembali ke Members...");
            
            // Coba klik menu Members lagi
            return await clickMembersSidebar(page);
        }
        return true;
    } catch (e) {
        return false;
    }
}

// ============================================
// FUNGSI-FUNGSI KICK MEMBER (PENDUKUNG)
// ============================================

// --- Fungsi untuk mendapatkan jumlah member terkini ---
async function getCurrentMemberCount(page) {
    return await page.evaluate(() => {
        // Cari semua elemen member
        const memberDivs = document.querySelectorAll('div.members-panel-content > div:nth-of-type(2) > div');
        let count = 0;
        
        memberDivs.forEach(div => {
            const text = div.textContent || '';
            // Hitung hanya yang bukan owner
            if ((text.includes('Collaborator') || text.includes('user')) && !text.includes('owner')) {
                count++;
            }
        });
        
        return count;
    });
}

// --- Fungsi untuk klik menu member berdasarkan urutan terkini ---
async function clickMemberMenuByOrder(page, order) {
    try {
        Logger.process(`Mencari menu untuk member urutan ke-${order}...`);
        
        // Dapatkan index member yang bisa di-kick
        const memberInfo = await page.evaluate(() => {
            const items = [];
            const memberDivs = document.querySelectorAll('div.members-panel-content > div:nth-of-type(2) > div');
            
            memberDivs.forEach((div, index) => {
                const text = div.textContent || '';
                // Hanya ambil yang bukan owner
                if ((text.includes('Collaborator') || text.includes('user')) && !text.includes('owner')) {
                    items.push({
                        index: index,
                        hasMenu: !!div.querySelector('svg')
                    });
                }
            });
            
            return items;
        });
        
        if (memberInfo.length === 0) {
            Logger.warn("Tidak ada member yang bisa di-kick");
            return false;
        }
        
        if (order > memberInfo.length) {
            Logger.warn(`Urutan ${order} melebihi jumlah member (${memberInfo.length})`);
            return false;
        }
        
        // Ambil index sebenarnya di DOM
        const targetIndex = memberInfo[order - 1].index;
        
        // Klik menu (svg) pada member tersebut
        const menuSelector = `div.members-panel-content > div:nth-of-type(2) > div:nth-child(${targetIndex + 1}) svg`;
        const menuElement = await page.$(menuSelector);
        
        if (menuElement && await menuElement.isVisible()) {
            await menuElement.click();
            Logger.info(`✅ Klik menu member urutan ke-${order}`);
            await Utils.sleep(1000);
            return true;
        }
        
        return false;
    } catch (e) {
        Logger.error(`Error click member menu: ${e.message}`);
        return false;
    }
}

// --- Fungsi untuk klik Remove dari dropdown ---
async function clickRemoveFromDropdown(page) {
    try {
        Logger.process("Mencari tombol Remove di dropdown...");
        
        const removeSelectors = [
            'div.members-panel-content > div:nth-of-type(2) div:nth-of-type(4) > div',
            'xpath//html/body/div[3]/div[2]/div/div[2]/div/section/main/div/div[2]/div[1]/div[2]/div[2]/span/div/div/div[4]/div',
            'main div:nth-of-type(4)',
            'aria/Remove',
            'text="Remove"',
            'button:has-text("Remove")'
        ];
        
        for (const selector of removeSelectors) {
            try {
                if (selector.startsWith('xpath')) {
                    const element = await page.$x(selector.replace('xpath', ''));
                    if (element.length > 0 && await element[0].isVisible()) {
                        await element[0].click();
                        Logger.info(`✅ Klik Remove dari dropdown (xpath)`);
                        await Utils.sleep(1000);
                        return true;
                    }
                } else {
                    const element = await page.$(selector);
                    if (element && await element.isVisible()) {
                        await element.click();
                        Logger.info(`✅ Klik Remove dari dropdown: ${selector}`);
                        await Utils.sleep(1000);
                        return true;
                    }
                }
            } catch (e) {}
        }
        
        return false;
    } catch (e) {
        Logger.error(`Error click remove dropdown: ${e.message}`);
        return false;
    }
}

// --- Fungsi untuk konfirmasi Remove di dialog ---
async function confirmRemoveDialog(page) {
    try {
        Logger.process("Mencari dialog konfirmasi...");
        
        const confirmSelectors = [
            'div:nth-of-type(5) button.lv-btn-primary > span',
            'xpath//html/body/div[5]/div[2]/div/div[2]/div[3]/button[2]/span',
            'div:nth-of-type(6) button.lv-btn-primary > span',
            'button.lv-btn-primary:has-text("Remove")',
            'button:has-text("Remove")',
            'button:has-text("Ya")',
            'button:has-text("Yes")'
        ];
        
        for (const selector of confirmSelectors) {
            try {
                if (selector.startsWith('xpath')) {
                    const element = await page.$x(selector.replace('xpath', ''));
                    if (element.length > 0 && await element[0].isVisible()) {
                        await element[0].click();
                        Logger.info(`✅ Konfirmasi Remove (xpath)`);
                        await Utils.sleep(2000);
                        return true;
                    }
                } else {
                    const element = await page.$(selector);
                    if (element && await element.isVisible()) {
                        await element.click();
                        Logger.info(`✅ Konfirmasi Remove: ${selector}`);
                        await Utils.sleep(2000);
                        return true;
                    }
                }
            } catch (e) {}
        }
        
        return false;
    } catch (e) {
        Logger.error(`Error confirm remove: ${e.message}`);
        return false;
    }
}

// ============================================
// FUNGSI LOGIN AND KICK (VERSI FINAL)
// ============================================

async function loginAndKick(email, password, kickMode) {
    let browser = null;
    let context = null;
    let page = null;
    
    try {
        Logger.process(`Login sebagai Head Team: ${email}`);
        
        browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
        context = await browser.newContext({
            userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        });
        page = await context.newPage();
        page.setDefaultTimeout(30000);
        
        // LOGIN
        await page.goto('https://www.capcut.com/id-id/signup', { waitUntil: 'domcontentloaded' });
        await Utils.sleep(2000);
        
        // ISI EMAIL
        let emailBox = page.locator('input[type="email"], input[name="email"], input[placeholder*="email"]').first();
        await emailBox.waitFor({ state: 'visible', timeout: 10000 });
        await emailBox.click();
        await emailBox.fill(email);
        console.log(chalk.gray(`[DEBUG] Email filled: ${email}`));
        
        // KLIK LANJUTKAN
        const continueBtn = await page.$('button:has-text("Lanjutkan")');
        if (continueBtn) await continueBtn.click();
        console.log(chalk.gray(`[DEBUG] Continue button clicked`));
        await Utils.sleep(3000);
        
        // ISI PASSWORD
        let passBox = page.locator('input[type="password"]').first();
        await passBox.waitFor({ state: 'visible', timeout: 10000 });
        await passBox.click();
        await passBox.fill(password);
        console.log(chalk.gray(`[DEBUG] Password filled`));
        
        // KLIK MASUK
        const loginBtn = await page.$('button:has-text("Masuk")');
        if (loginBtn) await loginBtn.click();
        console.log(chalk.gray(`[DEBUG] Login button clicked`));
        
        await page.waitForLoadState('networkidle', { timeout: 20000 }).catch(() => {});
        await Utils.sleep(5000);
        
        // CEK LOGIN
        const currentUrl = page.url();
        const pageText = await page.evaluate(() => document.body.innerText.toLowerCase());
        if (!pageText.includes('perpanjang pro') && !pageText.includes('dashboard') && !currentUrl.includes('my-edit')) {
            throw new Error('Login failed');
        }
        Logger.success("✅ Success login sebagai Head Team");
        
        // TUTUP POPUP AWAL
        await dismissAllPopups(page);
        
        // ===== NAVIGASI KE HALAMAN MEMBERS =====
        Logger.process("Membuka menu Settings...");
        
        // Step 1: Klik avatar
        if (!await clickAvatar(page)) {
            Logger.error("❌ Failed klik avatar");
            return;
        }
        
        // Step 2: Click Settings from dropdown
        if (!await clickSettingsFromDropdown(page)) {
            Logger.error("❌ Failed klik Settings dari dropdown");
            return;
        }
        
        // Step 3: Klik Members di sidebar
        if (!await clickMembersSidebar(page)) {
            Logger.error("❌ Failed klik menu Members");
            return;
        }
        
        // ===== KITA SEKARANG BERADA DI HALAMAN MEMBERS =====
        Logger.success("✅ Success masuk ke halaman Members");
        
        // TUNGGU SEBENTAR UNTUK DAFTAR MEMBER LOAD
        await Utils.sleep(3000);
        
        // ===== PROSES KICK MEMBER (VERSI BARU) =====
        if (kickMode === '1') {
            Logger.info("Akan meng-kick SEMUA member (kecuali Owner)...");
            
            let kickedCount = 0;
            let maxAttempts = 50; // Safety limit
            
            for (let attempt = 1; attempt <= maxAttempts; attempt++) {
                // Cek jumlah member yang tersisa
                const remainingMembers = await getCurrentMemberCount(page);
                
                if (remainingMembers === 0) {
                    Logger.success("✅ Semua member sudah di-kick!");
                    break;
                }
                
                Logger.info(`Member tersisa: ${remainingMembers} (Attempt ${attempt})`);
                
                console.log(chalk.gray(`\n--- [ KICK MEMBER ${kickedCount + 1} ] ---`));
                
                // Klik menu member urutan pertama
                if (!await clickMemberMenuByOrder(page, 1)) {
                    Logger.error("❌ Failed membuka menu member");
                    
                    // Coba refresh daftar
                    Logger.warn("Refresh halaman untuk memperbarui daftar member...");
                    await page.reload({ waitUntil: 'networkidle2' });
                    await Utils.sleep(3000);
                    await clickMembersSidebar(page);
                    await Utils.sleep(2000);
                    continue;
                }
                
                await Utils.sleep(1000);
                
                // Klik Remove dari dropdown
                if (!await clickRemoveFromDropdown(page)) {
                    Logger.error("❌ Failed klik Remove");
                    
                    // Coba tutup dropdown dengan Escape
                    await page.keyboard.press('Escape');
                    await Utils.sleep(1000);
                    continue;
                }
                
                await Utils.sleep(1000);
                
                // Konfirmasi di dialog
                if (!await confirmRemoveDialog(page)) {
                    Logger.error("❌ Failed konfirmasi Remove");
                    continue;
                }
                
                kickedCount++;
                Logger.success(`✅ Success meng-kick member ke-${kickedCount}`);
                await AccountHandler.saveKickResult(`Member-${kickedCount}`, "SUCCESS", "Kicked");
                
                // Tunggu sebentar setelah kick
                await Utils.sleep(3000);
                
                // Refresh halaman setiap 3 kali kick untuk menjaga akurasi
                if (kickedCount % 3 === 0) {
                    Logger.warn("Refresh halaman untuk memperbarui daftar member...");
                    await page.reload({ waitUntil: 'networkidle2' });
                    await Utils.sleep(3000);
                    await clickMembersSidebar(page);
                    await Utils.sleep(2000);
                }
            }
            
            Logger.success(`✅ Proses kick member done! Total success: ${kickedCount}`);
        }
        
        Logger.warn("Browser akan tetap terbuka. Tekan Ctrl+C di terminal untuk menutup program.");
        
    } catch (error) {
        Logger.error(`Error: ${error.message}`);
        if (page) await page.screenshot({ path: 'debug-error.png' });
    }
}

// ============================================
// MODE-MODE OPERASI
// ============================================

// --- MODE 1: Buat Account Baru SAJA ---
async function runMode1(count) {
    Logger.info("MODE 1: Create New Accounts ONLY (No Join)");
    const exploit = new CapCutExploit();
    Logger.process("Fetching email domains...");
    const domainList = await EmailService.getDomains();
    if (domainList.length === 0) { Logger.error("Failed mengambil domain!"); return; }
    let successCount = 0, failCount = 0;
    for (let i = 1; i <= count; i++) {
        console.log(chalk.gray(`\n--- [ AKUN ${i}/${count} ] ---`));
        try {
            const domain = domainList[Math.floor(Math.random() * domainList.length)];
            const name = faker.internet.userName().toLowerCase().replace(/[^a-z0-9]/g, '').substring(0, 8);
            const email = `${name}@${domain}`;
            const password = config.password || "DaysStore123!";
            Logger.process(`Email: ${chalk.white(email)}`);
            const encEmail = Utils.encryptToTargetHex(email);
            const encPass = Utils.encryptToTargetHex(password);
            Logger.info("Sending registration...");
            const regRes = await exploit.register(encEmail, encPass);
            if (regRes.message === "success") {
                Logger.success("OTP sent. Waiting...");
                let otp = null;
                const startTime = Date.now();
                const maxWaitTime = 90000;
                process.stdout.write(chalk.cyan(`${Utils.getCurrentTime()} [>] Cek inbox`));
                while (!otp && (Date.now() - startTime) < maxWaitTime) {
                    process.stdout.write(chalk.cyan("."));
                    await Utils.sleep(3000);
                    otp = await EmailService.checkInbox(email, domain);
                }
                console.log("");
                if (otp) {
                    Logger.success(`OTP: ${chalk.yellowBright(otp)}`);
                    const encOtp = Utils.encryptToTargetHex(otp);
                    const verifyRes = await exploit.verify(encEmail, encPass, encOtp);
                    if (verifyRes.data.message === "success") {
                        await AccountHandler.saveAccount(email, password, 'generated_accounts.txt');
                        Logger.success(`✅ Account saved in generated_accounts.txt`);
                        successCount++;
                    } else {
                        Logger.error(`Verifikasi failed: ${verifyRes.data.message}`);
                        failCount++;
                    }
                } else {
                    Logger.error("⏰ Timeout OTP");
                    failCount++;
                }
            } else {
                Logger.error(`Registrasi failed: ${regRes.message}`);
                failCount++;
            }
        } catch (error) {
            Logger.error(`Error: ${error.message}`);
            failCount++;
        }
        if (i < count) {
            const delay = 3000;
            Logger.warn(`Waiting ${delay/1000} seconds...`);
            await Utils.sleep(delay);
        }
    }
    Logger.success(`\n✅ Done! Success: ${successCount} | Failed: ${failCount}`);
}

// --- MODE 2: Create New Accounts + JOIN TEAM (2 WORKER, Auto-Retry 3x) ---
async function runMode2(teamLinks, headCount) {
    Logger.info(`MODE 2: Create New Accounts + JOIN TEAM (${headCount} Head @ 29 Account | 2 WORKER | Auto-Retry 3x)`);
    
    const domainList = await EmailService.getDomains();
    if (domainList.length === 0) { Logger.error("Failed mengambil domain!"); return; }

    let totalSuccess = 0, totalFail = 0, totalJoinSuccess = 0;

    // 1. Buat Task Queue (Kumpulkan semua job yang harus dieksekusi)
    const tasks = [];
    for (let h = 1; h <= headCount; h++) {
        const currentTeamLink = teamLinks[h - 1];
        for (let i = 1; i <= 29; i++) {
            tasks.push({ headIndex: h, accIndex: i, teamLink: currentTeamLink });
        }
    }

    let currentIndex = 0;
    const exploit = new CapCutExploit(); // Exploit bersifat stateless, aman dishare antar worker

    // 2. Fungsi Worker Utama
    const worker = async (workerId) => {
        while (currentIndex < tasks.length) {
            const task = tasks[currentIndex++];
            const { headIndex: h, accIndex: i, teamLink } = task;
            
            // Tagging unik untuk log agar rapi (cth: [W1] [H1-A5])
            const tag = `[W${workerId}] [H${h}-A${i}]`;

            console.log(chalk.magenta(`\n--- ${tag} MEMULAI PROSES ---`));
            let successForThisAccount = false;

            for (let attempt = 1; attempt <= 3; attempt++) {
                if (attempt > 1) {
                    Logger.warn(`${tag} ⚠️ Auto-retry ke-${attempt}...`);
                }

                try {
                    const domain = domainList[Math.floor(Math.random() * domainList.length)];
                    const name = faker.internet.userName().toLowerCase().replace(/[^a-z0-9]/g, '').substring(0, 8);
                    const email = `${name}@${domain}`;
                    const password = config.password || "DaysStore123!";

                    Logger.process(`${tag} Target Email: ${chalk.white(email)}`);
                    const encEmail = Utils.encryptToTargetHex(email);
                    const encPass = Utils.encryptToTargetHex(password);

                    Logger.info(`${tag} Sending registration...`);
                    const regRes = await exploit.register(encEmail, encPass);

                    if (regRes.message === "success") {
                        Logger.success(`${tag} OTP terkirim. Waiting for OTP... (Maks 90 seconds)`);
                        let otp = null;
                        const startTime = Date.now();
                        const maxWaitTime = 90000;

                        // Gunakan silent delay di worker (hilangkan titik-titik stdout agar log tidak tabrakan)
                        while (!otp && (Date.now() - startTime) < maxWaitTime) {
                            await Utils.sleep(5000); // Cek setiap 5 seconds
                            otp = await EmailService.checkInbox(email, domain);
                        }

                        if (otp) {
                            Logger.success(`${tag} OTP Found: ${chalk.yellowBright(otp)}`);
                            const encOtp = Utils.encryptToTargetHex(otp);
                            const verifyRes = await exploit.verify(encEmail, encPass, encOtp);

                            if (verifyRes.data.message === "success") {
                                await AccountHandler.saveAccount(email, password, 'generated_accounts.txt');
                                Logger.success(`${tag} ✅ Account tersimpan`);

                                if (verifyRes.cookies) {
                                    Logger.info(`${tag} Membuka Playwright untuk Join Team...`);
                                    const joinRes = await BrowserHandler.forceJoin(teamLink, verifyRes.cookies);

                                    if (joinRes.success) {
                                        Logger.success(`${tag} ✅ JOIN: ${joinRes.msg}`);
                                        await AccountHandler.saveResult(email, "SUCCESS", joinRes.msg, `MODE2_H${h}`);
                                        totalSuccess++;
                                        totalJoinSuccess++;
                                        successForThisAccount = true;
                                        break; // Success! Keluar dari loop retry
                                    } else {
                                        Logger.error(`${tag} ❌ JOIN GAGAL: ${joinRes.msg}`);
                                        await AccountHandler.saveResult(email, "FAILED", joinRes.msg, `MODE2_H${h}`);
                                    }
                                }
                            } else {
                                Logger.error(`${tag} Verifikasi failed: ${verifyRes.data.message}`);
                            }
                        } else {
                            Logger.error(`${tag} ⏰ Timeout OTP`);
                        }
                    } else {
                        Logger.error(`${tag} Registrasi failed: ${regRes.message}`);
                    }
                } catch (error) {
                    Logger.error(`${tag} Error eksekusi: ${error.message}`);
                }

                if (!successForThisAccount && attempt < 3) {
                    Logger.warn(`${tag} Failed! Waiting 5 seconds sebelum retry account ini...`);
                    await Utils.sleep(5000);
                } else if (!successForThisAccount && attempt === 3) {
                    Logger.error(`${tag} ❌ Failed memproses secara final setelah 3 kali percobaan.`);
                    totalFail++;
                }
            } // End Retry Loop

            // Beri jeda kecil agar request tidak terlalu agresif menumpuk
            if (currentIndex < tasks.length && successForThisAccount) {
                await Utils.sleep(2000);
            }
        } // End While Task Queue
    };

    // 3. Eksekusi Pool (2 Worker berjalan paralel)
    Logger.info("Mendelegasikan tugas ke 2 Worker secara paralel...");
    const workers = [];
    const NUM_WORKERS = 2; // Batas worker

    for (let w = 1; w <= NUM_WORKERS; w++) {
        workers.push(worker(w));
    }

    // Tunggu semua worker selesai
    await Promise.all(workers);

    Logger.success(`\n✅ Selesai Semua Task! Buat Account: ${totalSuccess} | Failed: ${totalFail} | Join Success: ${totalJoinSuccess}`);
}

// --- MODE 3: JOIN TEAM with Existing Accounts ---
async function runMode3(teamLink, accountFile, useCount) {
    Logger.info("MODE 3: JOIN TEAM with Existing Accounts");
    const accounts = await AccountHandler.loadAccountsFromFile(accountFile);
    if (accounts.length === 0) { Logger.error("Tidak ada account valid dalam file!"); return; }
    Logger.success(`Loaded ${chalk.yellow(accounts.length)} accounts`);
    const accountsToUse = useCount > 0 ? accounts.slice(0, useCount) : accounts;
    Logger.info(`Akan memproses ${chalk.yellow(accountsToUse.length)} accounts`);
    let successCount = 0, failCount = 0;
    for (let i = 0; i < accountsToUse.length; i++) {
        const account = accountsToUse[i];
        console.log(chalk.gray(`\n--- [ AKUN ${i + 1}/${accountsToUse.length} ] ---`));
        try {
            Logger.process(`Email: ${chalk.white(account.email)}`);
            Logger.info("Mencoba login dengan Playwright...");
            const loginResult = await Utils.loginWithExisting(account.email, account.password);
            if (loginResult.success) {
                Logger.success("✅ Login success!");
                if (loginResult.cookies) {
                    Logger.info("Proses join team...");
                    const joinRes = await BrowserHandler.forceJoin(teamLink, loginResult.cookies);
                    if (joinRes.success) {
                        Logger.success(`✅ JOIN: ${joinRes.msg}`);
                        await AccountHandler.saveResult(account.email, "SUCCESS", joinRes.msg, "MODE3");
                        successCount++;
                    } else {
                        Logger.error(`❌ JOIN GAGAL: ${joinRes.msg}`);
                        await AccountHandler.saveResult(account.email, "FAILED", joinRes.msg, "MODE3");
                        failCount++;
                    }
                } else {
                    Logger.error("❌ Tidak ada cookies dari login");
                    failCount++;
                }
            } else {
                Logger.error(`❌ Login failed: ${loginResult.error || 'Unknown error'}`);
                await AccountHandler.saveResult(account.email, "FAILED", loginResult.error || 'Login failed', "MODE3");
                failCount++;
            }
            if (i < accountsToUse.length - 1) {
                const delay = 3000;
                Logger.warn(`Waiting ${delay/1000} seconds...`);
                await Utils.sleep(delay);
            }
        } catch (error) {
            Logger.error(`Error: ${error.message}`);
            failCount++;
        }
    }
    Logger.success(`\n✅ Done! Join Success: ${successCount} | Failed: ${failCount}`);
}

// --- MODE 4: CHECK/LOGIN Existing Accounts (Validation) ---
async function runMode4(accountFile, useCount) {
    Logger.info("MODE 4: CHECK/LOGIN Existing Accounts (Validation)");
    const accounts = await AccountHandler.loadAccountsFromFile(accountFile);
    if (accounts.length === 0) { Logger.error("Tidak ada account dalam file!"); return; }
    const validFormatAccounts = accounts.filter(acc => acc.email && acc.email.includes('@') && acc.password && acc.password.length > 0);
    Logger.success(`Loaded ${chalk.yellow(accounts.length)} accounts (${validFormatAccounts.length} format valid)`);
    if (validFormatAccounts.length === 0) { Logger.error("Tidak ada account dengan format email valid!"); return; }
    const accountsToCheck = useCount > 0 ? validFormatAccounts.slice(0, useCount) : validFormatAccounts;
    Logger.info(`Akan mengecek ${chalk.yellow(accountsToCheck.length)} accounts`);
    let validCount = 0, invalidCount = 0;
    for (let i = 0; i < accountsToCheck.length; i++) {
        const account = accountsToCheck[i];
        console.log(chalk.gray(`\n--- [ CEK ${i + 1}/${accountsToCheck.length} ] ---`));
        try {
            Logger.process(`Email: ${chalk.white(account.email)}`);
            Logger.info("Mencoba login dengan Playwright...");
            const loginResult = await Utils.loginWithExisting(account.email, account.password);
            if (loginResult.success) {
                Logger.success(`✅ LOGIN BERHASIL - Account Valid`);
                await AccountHandler.saveLoginResult(account.email, "VALID", "Login success");
                validCount++;
            } else {
                Logger.error(`❌ LOGIN GAGAL - Account Invalid`);
                await AccountHandler.saveLoginResult(account.email, "INVALID", loginResult.error || "Login failed");
                invalidCount++;
            }
            if (i < accountsToCheck.length - 1) {
                const delay = 2000;
                await Utils.sleep(delay);
            }
        } catch (error) {
            Logger.error(`Error: ${error.message}`);
            invalidCount++;
        }
    }
    Logger.success(`\n✅ Done! Account Valid: ${validCount} | Invalid: ${invalidCount}`);
    Logger.info(`Hasil cek tersimpan di: login_results.txt`);
}

// --- MODE 5: KICK MEMBER ---
async function runMode5() {
    Logger.info("MODE 5: KICK MEMBER from Team");
    const headAccounts = await AccountHandler.loadAccountsFromFile('head.txt');
    if (headAccounts.length === 0) {
        Logger.error("Tidak ada account dalam file head.txt!");
        Logger.info("Buat file head.txt dengan format: email|password");
        return;
    }
    const validHeadAccounts = headAccounts.filter(acc => acc.email && acc.email.includes('@') && acc.password && acc.password.length > 0);
    if (validHeadAccounts.length === 0) {
        Logger.error("Tidak ada account valid dalam head.txt!");
        return;
    }
    console.log(chalk.gray("\n========================================="));
    Logger.info(`Found ${validHeadAccounts.length} account Head Team:`);
    console.log(chalk.gray("========================================="));
    for (let i = 0; i < validHeadAccounts.length; i++) {
        const acc = validHeadAccounts[i];
        console.log(chalk.white(`[${i + 1}] ${acc.email}`));
    }
    console.log(chalk.gray("=========================================\n"));
    
    const rl = createInterface({ input: process.stdin, output: process.stdout });
    const choice = await new Promise(resolve => {
        rl.question(chalk.yellow(`Pilih nomor account Head Team [1-${validHeadAccounts.length}]: `), (answer) => {
            resolve(parseInt(answer) - 1);
        });
    });
    if (choice < 0 || choice >= validHeadAccounts.length) {
        Logger.error("Pilihan invalid!");
        rl.close();
        return;
    }
    const selectedHead = validHeadAccounts[choice];
    Logger.success(`Memilih: ${chalk.yellow(selectedHead.email)}`);
    
    console.log(chalk.gray("\n========================================="));
    Logger.info("Pilih mode kick:");
    console.log(chalk.white("1. Kick SEMUA member (kecuali Head Team)"));
    console.log(chalk.white("2. Pilih member tertentu yang akan di-kick"));
    console.log(chalk.gray("=========================================\n"));
    
    const kickMode = await new Promise(resolve => {
        rl.question(chalk.yellow(`Pilih mode kick [1-2]: `), (answer) => {
            resolve(answer.trim() || '1');
        });
    });
    rl.close();
    
    await loginAndKick(selectedHead.email, selectedHead.password, kickMode);
}

// ============================================
// MAIN EXECUTION
// ============================================
(async () => {
    Utils.getBanner();

    const rl = createInterface({ input: process.stdin, output: process.stdout });
    
    console.log(chalk.yellow("\n📋 SELECT OPERATION MODE:"));
    console.log(chalk.white("1. 📝 Create New Accounts ONLY (Generator Only)"));
    console.log(chalk.white("2. 📝 + 🚀 Create New Accounts + JOIN TEAM"));
    console.log(chalk.white("3. 🚀 JOIN TEAM with Existing Accounts"));
    console.log(chalk.white("4. 🔍 CHECK/LOGIN Existing Accounts (Validation)"));
    console.log(chalk.white("5. 👢 KICK MEMBER from Team (Use head.txt)"));
    
    const mode = await new Promise(resolve => {
        rl.question(chalk.yellow("\nSelect [1-5]: "), (answer) => {
            resolve(answer.trim() || '1');
        });
    });
    
    if (!['1', '2', '3', '4', '5'].includes(mode)) {   
        console.log(chalk.red("[!] Mode invalid!"));
        process.exit(1);
    }
    
    let teamLinks = []; // Digunakan khusus mode 2
    let teamLink = '';  // Digunakan khusus mode 3
    let accountFile = 'accounts.txt';
    let useCount = 0;
    let headCountMode2 = 1;
    
    if (mode === '2') {
        headCountMode2 = await new Promise(resolve => {
            rl.question(chalk.yellow(`\n📊 Berapa account head yang mau digenerate? (Setiap head otomatis = 29 account): `), (answer) => {
                resolve(parseInt(answer) || 1);
            });
        });

        for (let i = 0; i < headCountMode2; i++) {
            const link = await new Promise(resolve => {
                rl.question(chalk.yellow(`🔗 Masukkan Team Invite Link untuk Head ${i + 1}: `), (answer) => {
                    if (!answer) {
                        console.log(chalk.red("[!] Link tidak boleh kosong!"));
                        process.exit(0);
                    }
                    resolve(answer.trim());
                });
            });
            teamLinks.push(link);
        }
    } else if (mode === '3') {
        teamLink = await new Promise(resolve => {
            rl.question(chalk.yellow(`\n🔗 Masukkan Team Invite Link: `), (answer) => {
                if (!answer) {
                    console.log(chalk.red("[!] Link tidak boleh kosong!"));
                    process.exit(0);
                }
                resolve(answer.trim());
            });
        });
    } else if (mode === '1') {
        useCount = await new Promise(resolve => {
            rl.question(chalk.yellow(`\n📊 Number of new accounts to create: `), (answer) => {
                resolve(parseInt(answer) || 1);
            });
        });
    }
    
    if (mode === '3' || mode === '4') {
        accountFile = await new Promise(resolve => {
            rl.question(chalk.yellow(`\n📁 Nama file account (default: accounts.txt): `), (answer) => {
                resolve(answer.trim() || 'accounts.txt');
            });
        });
        
        const useAll = await new Promise(resolve => {
            rl.question(chalk.yellow(`📊 Gunakan semua account? (y/n): `), (answer) => {
                resolve(answer.toLowerCase() === 'y');
            });
        });
        
        if (!useAll) {
            useCount = await new Promise(resolve => {
                rl.question(chalk.yellow(`📊 Jumlah account yang dipakai: `), (answer) => {
                    resolve(parseInt(answer) || 1);
                });
            });
        } else {
            useCount = 0;
        }
    }
    
    rl.close();
    
    console.log(chalk.gray("\n--------------------------------------------------"));
    
    let startTime = Date.now();
    
    switch(mode) {
        case '1': await runMode1(useCount); break;
        case '2': await runMode2(teamLinks, headCountMode2); break;
        case '3': await runMode3(teamLink, accountFile, useCount); break;
        case '4': await runMode4(accountFile, useCount); break;
        case '5': await runMode5(); break;
    }
    
    let endTime = Date.now();
    let totalTime = Math.round((endTime - startTime) / 1000);
    
    console.log(chalk.gray("\n--------------------------------------------------"));
    Logger.success("🎯 PROGRAM COMPLETED!");
    Logger.info(`⏱️ Total time: ${totalTime} seconds`);
    
    if (mode === '1' || mode === '2') Logger.info(`📁 New accounts saved in: generated_accounts.txt`);
    if (mode === '2' || mode === '3') Logger.info(`📁 Hasil join tersimpan di: join_results.txt`);
    if (mode === '4') Logger.info(`📁 Hasil cek account tersimpan di: login_results.txt`);
    if (mode === '5') Logger.info(`📁 Hasil kick member tersimpan di: kick_results.txt`);
    
    console.log(chalk.gray("--------------------------------------------------"));
    
})();