@echo off
title [ DAYS STORE ] - CAPCUT AUTO JOIN
color 0E
chcp 65001 >nul

:menu
cls
echo.
echo   ========================================
echo       [ DAYS STORE - CAPCUT AUTO JOIN ]
echo       [          MAIN MENU            ]
echo   ========================================
echo.
echo ========================================
echo       4 OPERATION MODES AVAILABLE
echo ========================================
echo.
echo [1] RUN PROGRAM (Multi Mode)
echo [2] EDIT CONFIG.JSON
echo [3] VIEW ACCOUNT FILES
echo [4] REINSTALL DEPENDENCIES
echo [5] EXIT
echo.
echo ========================================
echo.

set /p pilih="Select menu [1-5]: "

if "%pilih%"=="1" goto run
if "%pilih%"=="2" goto editconfig
if "%pilih%"=="3" goto viewfiles
if "%pilih%"=="4" goto reinstall
if "%pilih%"=="5" goto exit
goto menu

:run
cls
echo.
echo ========================================
echo           RUNNING PROGRAM...
echo ========================================
echo.
echo Make sure you have installed dependencies with install.bat
echo.
if not exist node_modules (
    echo [WARNING] node_modules not found!
    echo Run install.bat first.
    pause
    goto menu
)
echo.
echo Running script...
echo.

:: Run node with full path
node "%~dp0script.js"

echo.
echo ========================================
echo.
echo Program execution finished.
pause
goto menu

:editconfig
cls
echo.
echo ========================================
echo        EDIT CONFIG.JSON
echo ========================================
echo.
if exist config.json (
    notepad config.json
) else (
    echo [ERROR] config.json file not found!
    echo.
    echo Run install.bat first to create config.json
)
pause
goto menu

:viewfiles
cls
echo.
echo ========================================
echo           ACCOUNT FILES LIST
echo ========================================
echo.

echo --------------------------------
echo accounts.txt - Existing Accounts:
echo --------------------------------
if exist accounts.txt (
    type accounts.txt
) else (
    echo File not found
)
echo.
echo --------------------------------
echo generated_accounts.txt - New Accounts:
echo --------------------------------
if exist generated_accounts.txt (
    type generated_accounts.txt
) else (
    echo File not found
)
echo.
echo --------------------------------
echo join_results.txt - Join Logs:
echo --------------------------------
if exist join_results.txt (
    type join_results.txt
) else (
    echo No join logs yet
)
echo.
echo --------------------------------
echo login_results.txt - Account Check Logs:
echo --------------------------------
if exist login_results.txt (
    type login_results.txt
) else (
    echo No account check logs yet
)
echo.
echo ========================================
echo.
pause
goto menu

:reinstall
cls
echo.
echo ========================================
echo      REINSTALL DEPENDENCIES
echo ========================================
echo.
call install.bat
pause
goto menu

:exit
cls
echo.
echo ========================================
echo     Thank you for using
echo     DAYS STORE - CAPCUT AUTO JOIN
echo ========================================
echo.
timeout /t 2 /nobreak >nul
exit